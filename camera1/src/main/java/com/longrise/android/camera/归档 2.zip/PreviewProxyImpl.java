package com.longrise.android.camera;

import com.longrise.android.camera.base.PreviewProxy;

/**
 * Created by godliness on 2020-08-05.
 *
 * @author godliness
 */
public interface PreviewProxyImpl extends PreviewProxy {
}
