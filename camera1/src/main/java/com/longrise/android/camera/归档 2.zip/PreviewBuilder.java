package com.longrise.android.camera;

import android.support.annotation.DrawableRes;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.FrameLayout;

import com.longrise.android.camera.base.BaseBuilder;
import com.longrise.android.camera.base.BaseFragment;

/**
 * Created by godliness on 2020-08-05.
 *
 * @author godliness
 */
public final class PreviewBuilder extends BaseBuilder<PreviewBuilder, PreviewProxyImpl> {

    int mTemplate = -1;
    FrameLayout.LayoutParams mLayoutParams;
    View mTemplateView;

    public PreviewBuilder(AppCompatActivity host) {
        super(host);
    }

    public PreviewBuilder templateResource(@DrawableRes int drawableRes) {
        return templateResource(drawableRes, null);
    }

    public PreviewBuilder templateResource(@DrawableRes int drawableRes, FrameLayout.LayoutParams params) {
        if (mTemplateView != null) {
            throw new IllegalStateException("Can only set one");
        }
        this.mTemplate = drawableRes;
        this.mLayoutParams = params;
        return this;
    }

    public PreviewBuilder templateView(View view) {
        if (mTemplate != -1) {
            throw new IllegalStateException("Can only set one");
        }
        this.mTemplateView = view;
        return this;
    }

    @Override
    protected BaseFragment createPreview() {
        return new PreviewFragment();
    }
}
